package com.example.administrator;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class SearchActivity extends AppCompatActivity {

    //views
    private Button btnPaired;
    private ListView deviceList;
    private ImageView decoration;
    private RelativeLayout emptyView;

    //bluetooth
    private BluetoothAdapter bluetoothAdapter = null;
    private Set<BluetoothDevice> pairedDevices;
    public static final String EXTRA_ADDRESS = "DEVICE_ADDRESSES";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        //find views
        btnPaired = (Button) findViewById(R.id.paired_device_button);
        deviceList = (ListView) findViewById(R.id.list);
        decoration = (ImageView) findViewById(R.id.decoration_image);
        emptyView = (RelativeLayout) findViewById(R.id.empty_view);

        //empty view
        emptyView.setVisibility(View.VISIBLE);//show the empty view
        decoration.setVisibility(View.INVISIBLE); //hide the decoration;

        //check the device's bluetooth
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) { //bluetooth is not supported
            Toast.makeText(this, getString(R.string.not_support_bluetooth), Toast.LENGTH_LONG).show();
            finish(); //finish the activity
        } else if (!bluetoothAdapter.isEnabled()) {
            //ask the user to turn on the bluetooth
            Intent turnOnBT = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnOnBT, 1);
        }
        btnPaired.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pairedDeviceList();
            }
        });
    }

    private void pairedDeviceList() {
        pairedDevices = bluetoothAdapter.getBondedDevices();
        ArrayList arrayList = new ArrayList();

        if (pairedDevices.size() > 0) {
            for (BluetoothDevice bt : pairedDevices) {
                arrayList.add(bt.getName()+"\n"+bt.getAddress()); //get the devices name and address
            }
            //show the decoration if the list is not empty and hide the empty view
            decoration.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.INVISIBLE);
        } else {
            Toast.makeText(this, getString(R.string.no_paired_device_found), Toast.LENGTH_LONG).show();
        }

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, R.layout.simple_list_item, arrayList);
        deviceList.setAdapter(arrayAdapter);
        deviceList.setOnItemClickListener(myListClickListener);
    }
    //list item click listener
    private AdapterView.OnItemClickListener myListClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            //get the device MAC address, the last 17 chars in the view
            String info = ((TextView) view).getText().toString();
            String address = info.substring(info.length()-17);

            //send an intent to start another activity
            Intent intent = new Intent(SearchActivity.this, ControlActivity.class);
            intent.putExtra(EXTRA_ADDRESS, address);
            startActivity(intent);
        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.info: //go to the info activity
                Intent intent = new Intent(SearchActivity.this, InfoActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
