package com.example.administrator;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.UUID;

public class ControlActivity extends AppCompatActivity {

    //views
    private ImageButton Front, Back, Left, Right;
    private Switch LEDSwitch;
    private SeekBar speedBar;
    private TextView speedText;

    String address = null;

    //bluetooth
    private ProgressDialog progressDialog;
    BluetoothAdapter bluetoothAdapter = null;
    BluetoothSocket bluetoothSocket = null;
    private boolean isBtConnected = false;

    //SSP UUID
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);

        //get the intent information
        Intent intent = getIntent();
        address = intent.getStringExtra(SearchActivity.EXTRA_ADDRESS);

        //find views by ids
        Front = (ImageButton) findViewById(R.id.front_button);
        Back = (ImageButton) findViewById(R.id.back_button);
        Left = (ImageButton) findViewById(R.id.left_button);
        Right = (ImageButton) findViewById(R.id.right_button);
        LEDSwitch = (Switch) findViewById(R.id.led_switch);
        speedBar = (SeekBar) findViewById(R.id.seek_bar);
        speedText = (TextView) findViewById(R.id.speed_text);

        //execute the class to connect
        new ConnectBt().execute();

        //commands to be send through the bluetooth
        Front.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: //user pressed
                        sendFront();
                        return true;
                    case MotionEvent.ACTION_UP: //user released
                        frontStop();
                        return true;
                }
                return false;
            }
        });

        Back.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendBack();
                        return true;
                    case MotionEvent.ACTION_UP:
                        backStop();
                        return true;
                }
                return false;
            }
        });

        Left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendLeft();
                        return true;
                    case MotionEvent.ACTION_UP:
                        leftStop();
                        return true;
                }
                return false;
            }
        });

        Right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sendRight();
                        return true;
                    case MotionEvent.ACTION_UP:
                        rightStop();
                        return true;
                }
                return false;
            }
        });

        //LED light switch
        LEDSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) { //turn on the LED
                    sendOn();
                } else { //turn off the LED
                    sendOff();
                }
            }
        });

        //speed bar
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                speedText.setText(getString(R.string.speed)+progress+"%"); //show the progress

                //send the percentage through bluetooth
                if (progress==100) { //maximum
                    send("m",getString(R.string.speed_error));
                } else {
                    send(String.valueOf(progress/10), getString(R.string.speed_error));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.control_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.info: //go to the info activity
                Intent intent = new Intent(ControlActivity.this, InfoActivity.class);
                startActivity(intent);
                return true;
            case R.id.disconnect:
                disconnect();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //helper method to show message as toast
    private void msg(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
    }

    //disconnect method
    private void disconnect() {
        if (bluetoothSocket != null) {
            try {
                bluetoothSocket.close();
                finish(); //exit the activity
            } catch (IOException e) {
                msg(getString(R.string.disconnect_failed));
            }
        }
    }

    //send method
    private void send(String s, String errorMsg) {
        if (bluetoothSocket != null) {
            try {
                bluetoothSocket.getOutputStream().write(s.getBytes());
            } catch (IOException e) {
                msg(errorMsg);
            }
        }
    }

    //front methods
    private void sendFront() {
        send("F",getString(R.string.front_error));
    }
    private void frontStop() {
        send("f",getString(R.string.front_error));
    }

    //back methods
    private void sendBack() {
        send("B",getString(R.string.back_error));
    }
    private void backStop() {
        send("b",getString(R.string.back_error));
    }

    //left methods
    private void sendLeft() {
        send("L",getString(R.string.left_error));
    }
    private void leftStop() {
        send("l",getString(R.string.left_error));
    }

    //right methods
    private void sendRight() {
        send("R",getString(R.string.right_error));
    }
    private void rightStop() {
        send("r",getString(R.string.right_error));
    }

    //led methods
    private void sendOn() {
        send("O", getString(R.string.led_on_error));
    }
    private void sendOff() {
        send("o", getString(R.string.led_off_error));
    }

    //bluetooth helper class
    private class ConnectBt extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected void onPreExecute() { //show a progress dialog
            progressDialog = ProgressDialog.show(ControlActivity.this, getString(R.string.connecting), getString(R.string.please_wait));
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                if (bluetoothSocket==null || !isBtConnected) {
                    bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                    BluetoothDevice bluetoothDevice = bluetoothAdapter.getRemoteDevice(address); //connect to the device
                    bluetoothSocket = bluetoothDevice.createInsecureRfcommSocketToServiceRecord(myUUID);
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery(); //cancel discovery
                    bluetoothSocket.connect();
                }
            } catch (IOException e) {
                ConnectSuccess = false; //connect failed
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (!ConnectSuccess) {
                msg(getString(R.string.connection_failed));
                finish();//finish the activity
            } else {
                msg(getString(R.string.connected));
                isBtConnected = true;
            }
            progressDialog.dismiss(); //dismiss the progress dialog
        }
    }
}
